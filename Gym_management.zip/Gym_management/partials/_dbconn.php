<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "gym_db";

//create Connection
$conn = mysqli_connect($servername,$username,$password,$database);


#die if unSuccessful
if(!$conn){
  die("Sory we failed to connect: ". mysqli_connect_error());

}

?>